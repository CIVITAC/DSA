<!doctype html>
<html>
<head>
</head>
<body>
<script type="text/javascript">
var x = 20;
	var data1= prompt("Do you have enough water");
		if(data1 == "yes")
		{
			var a = prompt("Chose district  01.Ajmer  02.Alwar  03.Banswara  04.Baran  05.Barmer  06.Bharatpur  07.Bhilwara  08.Bikaner  09.Bundi  10.Chittorgarh  11.Churu  12.Dausa  13.Dholpur  14.Dungarpur  15.Hanumangarh  16.Jaipur  17.Jaisalmer  18.Jalor  19.Jhalawar  20.Jhunjhunu  21.Jodhpur  22.Karauli  23.Kota  24.Nagaur  25.Pali  26.Pratapgarh  27.Rajsamand  28.Sawai Madhopur  29.Sikar  30.Sirohi");
			if(a == 1)
			{
				x = x + 462.2; 
			}
			else if(a == 2)
			{
				x = x + 630.9; 
			}
			else if(a == 3)
			{
				x = x + 883; 
			}
			else if(a == 4)
			{
				x = x + 852.7; 
			}
			else if(a == 5)
			{
				x = x + 268.6; 
			}
			else if(a == 6)
			{
				x = x + 621; 
			}
			else if(a == 7)
			{
				x = x + 630.2; 
			}
			else if(a == 8)
			{
				x = x + 274.0; 
			}
			else if(a == 9)
			{
				x = x + 705.6; 
			}
			else if(a == 10)
			{
				x = x + 765.3; 
			}
			else if(a == 11)
			{
				x = x + 369.6; 
			}
			else if(a == 12)
			{
				x = x + 674.8; 
			}
			else if(a == 13)
			{
				x = x + 722.1; 
			}
			else if(a == 14)
			{
				x = x + 677.8; 
			}
			else if(a == 15)
			{
				x = x + 252.9; 
			}
			else if(a == 16)
			{
				x = x + 301.6; 
			}
			else if(a == 17)
			{
				x = x + 577.2; 
			}
			else if(a == 18)
			{
				x = x + 181.2; 
			}
			else if(a == 19)
			{
				x = x + 427.1; 
			}
			else if(a == 20)
			{
				x = x + 920.2; 
			}
			else if(a == 21)
			{
				x = x + 481; 
			}
			else if(a == 22)
			{
				x = x + 308.1; 
			}
			else if(a == 23)
			{
				x = x + 696.2; 
			}
			else if(a == 24)
			{
				x = x + 807.9; 
			}
			else if(a == 25)
			{
				x = x + 394.1; 
			}
			else if(a == 26)
			{
				x = x + 485.7; 
			}
			else if(a == 27)
			{
				x = x + 915.3; 
			}
			else if(a == 28)
			{
				x = x + 554.5; 
			}
			else if(a == 29)
			{
				x = x + 721.0; 
			}
			else if(a == 30)
			{
				x = x + 913.4; 
			}
			else
			{
				document.write("Invalid");
			}

			var c =1;
			if(x >400)
			{
				document.write("Maize");
			}
			if(x >650)
			{
				document.write("Cotton");
				document.write("\n");
			}
			if(x >300)
			{
				document.write("wheat");
				document.write("\n");
			}
			if(x >300)
			{
				document.write("Gram");
				document.write("\n");
			}
			if(x >500)
			{
				document.write("Bajra");
				document.write("\n");
			}
		}
		else
		{
			var c =1;
			if(x >400)
			{
				document.write("Maize");
				document.write("\n");
			}
			if(x >650)
			{
				document.write("Cotton");
				document.write("\n");
			}
			if(x >300)
			{
				document.write("wheat");
				document.write("\n");
			}
			if(x >300)
			{
				document.write("Gram");
				document.write("\n");
			}
			if(x >500)
			{
				document.write("Bajra");
				document.write("\n");
			}
		}
</script>
</body>
</html>