<!DOCTYPE html>
<html>
<head>
<style>

#neel1{
    position: fixed;
    top: 0;
    width: 100%;
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

#name {
    float: left;
}

#name a {
    display: block;
    color: white;
    text-align: center;
    padding: 20px 83px;
    text-decoration: none;
}

#name a:hover:not(.active) {
    background-color: #111;
}

.active {
    background-color: #4CAF50;
}
#name a:hover(.active) {
    background-color: #4CAF50;
}


#neel{
    position: fixed;
    top: 58px;
    height: 100%;
    width: 15%;
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #f2f2f2;
}
#active  {
    display: block;
    color: black;
    text-align: center;
    padding: 15px 23px;
    text-decoration: none;
    font-size: 25px;
}
#name a:hover {
    color: green;
  }
</style>
<script type="text/javascript">


</script>
</head>
<body>

<ul id="neel1">
  <li id="name"><a class="active" href="#home">Home</a></li>
  <li id="name"><a href="#scheme">Scheme</a></li>
  <li id="name"><a href="#contact">Contact</a></li>
  <li id="name"><a href="#rajasthangov">rajasthan.gov</a></li>
  <li id="name" style="float:right"><a href="#logout">Logout</a></li>
</ul>

<div id="neel">
<a id="active" href="#water_protection">Water protection</a></br>
<a id="active" href="#what_to_do">What to do?</a></br>
<a id="active" href="#site_map">Site map</a></br>
<a id="active" href="#contact_gov">Contact gov</a></br>
<a id="active" href="raj4.php">data predictivity</a></br>
</div>
</div>
</body>
</html>
